@echo off

set DOCBOOK=C:\programs\DocBook
set PYTHON=c:\Python33\python.exe

set LANG=%1

if /i "%LANG%" == "clean" (
	goto :CLEAN
)


if /i not "%LANG%" == "ru" (
	if /i not "%LANG%" == "en" (
		echo ERROR: 
		echo   Language tag is not correct
		echo.
		goto :HELP
	)
)

set DO_HTML=0
set DO_CHM=0
set DO_PUB=0

set DONE_HTML=0
set DONE_CHM=0
set DONE_PUB=0

set PARAM1=%2
if /i "%PARAM1%" == "html" set DO_HTML=1 
if /i "%PARAM1%" == "chm" set DO_CHM=1 
if /i "%PARAM1%" == "pub" set DO_PUB=1 

set PARAM2=%3
if /i "%PARAM2%" == "html" set DO_HTML=1 
if /i "%PARAM2%" == "chm" set DO_CHM=1 
if /i "%PARAM2%" == "pub" set DO_PUB=1 

set PARAM3=%4
if /i "%PARAM3%" == "html" set DO_HTML=1 
if /i "%PARAM3%" == "chm" set DO_CHM=1 
if /i "%PARAM3%" == "pub" set DO_PUB=1 

if /i "%LANG%" == "ru" set PREF=ru
if /i "%LANG%" == "en" set PREF=en

set APPNAME=rezonator

REM ----------------------------------------------------------
REM              compile docbook into html

if %DO_HTML% == 1 (
	echo.
	echo Compiling DOCBOOK file into HTML: 
	echo.

	subst R: %DOCBOOK%

	REM CHM-компилятор не может найти файлы, если они лежат выше файла проекта
	REM junction - утилита Руссиновича для создания символических ссылок на NTFS
	REM (есть еще системная команда linkd, но она входит в Windows Resources Kit)
	junction .\elems ..\elems
	junction .\toolbar ..\img
	
	%PYTHON% make_docbook.py %PREF%-interface.docbook
	%PYTHON% make_docbook.py %PREF%-schema.docbook
	%PYTHON% make_docbook.py %PREF%-matrices.docbook
	%PYTHON% make_docbook.py %PREF%-elems.docbook
	
	set XSL_FILE=%PREF%-settings.xsl
	set INPUT_FILE=%PREF%-index.docbook
	set OUTPUT_FILE=index.html

	@echo on
	%DOCBOOK%/bin/xsltproc --nonet --output %OUTPUT_FILE% %XSL_FILE% %INPUT_FILE%
	@echo off
	
	set DONE_HTML=1
)

REM ----------------------------------------------------------
REM              make chm from html

if %DO_CHM% == 1 (
	echo.
	echo Making CHM from HTML files: 
	echo.

	@echo on
	
	REM CHM-компилятор не может найти файлы, если они лежат выше файла проекта
	REM junction - утилита Руссиновича для создания символических ссылок на NTFS
	REM (есть еще системная команда linkd, но она входит в Windows Resources Kit)
	junction .\elems ..\elems
	junction .\toolbar ..\img
	
	REM Docbook генерит индексы в том порядке, в котором они появляются при компиляции
	REM Скрипт генерит новый отсортированный индекс и создает новый файл проекта
	%PYTHON% make_index.py %LANG%
	
	"%DOCBOOK%\..\HTML Help Workshop\hhc" default1.hhp
	
	@echo off

	set DONE_CHM=1
)

REM ----------------------------------------------------------
REM              publish chm to release folder

if %DO_PUB% == 1 (
	echo.
	echo Publishing CHM file: 
	echo.
	
	set CHM_SRC=default.%PREF%.chm
	set CHM_DEST=..\out\%APPNAME%.%PREF%.chm
	
	echo Source: "%CHM_SRC%"
	echo Target: "%CHM_DEST%"
	
	@echo on
	copy /Y /B %CHM_SRC% %CHM_DEST%   
	@echo off

	set DONE_PUB=1
)

REM ----------------------------------------------------------

if %DONE_HTML% == 0 (
	if %DONE_CHM% == 0 (
		if %DONE_PUB% == 0 (
			echo ERROR: 
			echo   No action specified: HTML^|CHM^|PUB
			echo.
			goto :HELP;
		)
	)
)

goto :EXIT;

REM ----------------------------------------------------------
REM                 clean folder subroutine

:CLEAN

@echo on
del /F *.html
del /F *.chm
del /F *.hhp
del /F *.hhk
del /F *.hhc
del /F *.docbook1

goto :EXIT

REM ----------------------------------------------------------
REM                   print help subroutine

:HELP
echo USING: 
echo   make.cmd RU^|EN [HTML] [CHM] [PUB]
echo     EN or RU - language to process
echo   Actions:
echo     HTML - compile docbook into html
echo     CHM - make chm from html
echo     PUB - publish chm to release folder  

:EXIT