<?xml version="1.0" encoding="windows-1251"?> 
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
	<!--<xsl:import href="R:/xsl/html/chunk.xsl"/>-->
	<xsl:import href="R:/xsl/htmlhelp/htmlhelp.xsl"/>
	
	<xsl:param name="use.id.as.filename" select="1"/>	
	
	<xsl:param name="chunker.output.encoding">utf-8</xsl:param>
	<xsl:param name="chunker.output.indent">yes</xsl:param> 
	
	<xsl:param name="chunk.first.sections" select="1"/>

	<xsl:param name="chapter.autolabel" select="0" />
	<xsl:param name="section.autolabel" select="0" />
	<xsl:param name="appendix.autolabel" select="0" />
	
	<xsl:param name="html.stylesheet">main.css</xsl:param>
	<xsl:param name="html.stylesheet.type">text/css</xsl:param>
	
	<xsl:param name="menuchoice.separator"> + </xsl:param>
	<xsl:param name="menuchoice.menu.separator">&#xA0;&#xA0;&#x025BA;&#xA0;&#xA0;</xsl:param>

	<xsl:param name="suppress.header.navigation" select="1" />
	<xsl:param name="suppress.footer.navigation" select="1" />

	<xsl:param name="toc.section.depth" select="1" />
	
	<xsl:param name="htmlhelp.encoding">utf-8</xsl:param>
	<xsl:param name="htmlhelp.hhp">default.hhp</xsl:param>
	<xsl:param name="htmlhelp.hhc">default.hhc</xsl:param>
	<xsl:param name="htmlhelp.hhk">default.hhk</xsl:param>
	<xsl:param name="htmlhelp.chm">default.en.chm</xsl:param>
	<xsl:param name="htmlhelp.hhc.section.depth">1</xsl:param>
	<xsl:param name="htmlhelp.hhc.show.root" select="0" />
	<xsl:param name="htmlhelp.use.hhk" select="1" />
	<xsl:param name="htmlhelp.enumerate.images" select="1" />
	<xsl:param name="htmlhelp.button.jump1" select="1" />
	<xsl:param name="htmlhelp.button.jump1.url">www://rezonator.orion-project.org</xsl:param>
	<xsl:param name="htmlhelp.button.jump1.title">WWW</xsl:param>
	<xsl:param name="htmlhelp.hhp.tail">
[FILES]
img\logo.png
img\info.png
	</xsl:param>


</xsl:stylesheet>
